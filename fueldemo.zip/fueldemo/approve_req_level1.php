<?php
	include 'includes/session.php';

	if(isset($_POST['update'])){
		$id = $_POST['id'];
		$comment=$_POST['comment'];
		$user=$_POST['user'];
		$am=$_POST['amount'];
		if($delete=$conn->query("UPDATE `fuels_request` SET `approve_reject_level1`='$user approved',	`level1_date`=now(),`ap_rej_comments`='$comment',`status`='approved',`rec_amount`='$am' WHERE `request_id`='$id'"))
		{
	
			$_SESSION['success'] = 'Requisition approved successfully!!';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	
	header('location:approved_request.php');
	}
?>
<?php
	include 'includes/session.php';

	if(isset($_POST['reject'])){
		$id = $_POST['id'];
		$comment=$_POST['comment'];
		$user=$_POST['user'];
		
		if($user=='logistic')
		{
		    $delete=$conn->query("UPDATE `fuels_request` SET `approve_reject_level1`='$user Rejected',	`level1_date`=now(),`ap_rej_comments`='$comment',`status`='rejected' WHERE `request_id`='$id'");
		   
		    $_SESSION['success'] = 'Requisition Rejected successfully!!';
		}
		else
		{
		 $delete=$conn->query("UPDATE `fuels_request` SET `approve_reject_level2`='$user Rejected',	`level1_date`=now(),`ap_rej_comments`='$comment',`status`='rejected' WHERE `request_id`='$id'");
		  
		   $_SESSION['success'] = 'Requisition Rejected successfully!!';
				}
	header('location:rejected_request.php');
	}
?>
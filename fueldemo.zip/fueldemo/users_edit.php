<?php
	include 'includes/session.php';

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$fname = $_POST['firstname'];
		$lname = $_POST['lastname'];
		$phone = $_POST['phone'];
		$level= $_POST['level'];
		$username= $_POST['email'];
		$phone = $_POST['phone'];
		$pass=$_POST['password'];
		$nid=$_POST['nid'];
$password = password_hash($pass, PASSWORD_DEFAULT);
		$sql = "UPDATE `users` SET `username`='$username',`phone`='$phone',`password`='$password',`firstname`='$fname',`lastname`='$lname',`level`='$level',`nid`='$nid' WHERE `id`='$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'user info updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		$_SESSION['error'] = 'Fill up edit form first';
	}

	header('location:users.php');

?>
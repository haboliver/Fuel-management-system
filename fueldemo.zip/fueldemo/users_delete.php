<?php
	include 'includes/session.php';

	if(isset($_POST['delete'])){
		$id = $_POST['id'];
		$sql = "DELETE FROM users WHERE id = '$id'";
		if($conn->query($sql)){
		$delete=$conn->query("DELETE FROM `requests` WHERE `c_id`='$id'");
			$del=$conn->query("DELETE FROM `approved_request` WHERE `customer_id`='$id'");
			$_SESSION['success'] = 'Account deleted successfully and its information';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		$_SESSION['error'] = 'Select item to delete first';
	}

	header('location:users.php');
	
?>
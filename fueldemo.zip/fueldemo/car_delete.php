<?php
	include 'includes/session.php';

	if(isset($_POST['delete'])){
		$id = $_POST['id'];
		$sql = "DELETE FROM `cars` WHERE `car_id`='$id'";
		if($conn->query($sql)){
		$delete=$conn->query("SELECT * FROM `fuels_request` WHERE `car_id`='$id'");
	
			$_SESSION['success'] = 'Car info deleted successfully and its information';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		$_SESSION['error'] = 'Select item to delete first';
	}

	header('location:cars.php');
	
?>
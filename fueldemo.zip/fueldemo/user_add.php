<?php
	include 'includes/session.php';

	if(isset($_POST['save'])){
	
		$username = $_POST['username'];
		$phone = $_POST['phone'];
		$pass = $_POST['password'];
		$firstname = $_POST['firstname'];
		$level = $_POST['level'];
		$lastname = $_POST['lastname'];
		$photo = $_FILES['photo']['name'];
		$password = password_hash($pass, PASSWORD_DEFAULT);
		$select="SELECT * FROM `users` WHERE `username`='$username'";
		$query = $conn->query($select);
		if($query->num_rows == 1){
			if(!isset($_SESSION['error'])){
				$_SESSION['error'] = array();
			}
			$_SESSION['error'][] = 'User allready Recorded!!';
		}
		else{
		move_uploaded_file($_FILES['photo']['tmp_name'], 'images/'.$photo);
			$sql = "INSERT INTO `users`(`username`,`phone`, `password`, `firstname`, `lastname`, `level`, `photo`, `created_on`) VALUES ('$username','$phone','$password','$firstname','$lastname','$level','$photo',now())";
			if($conn->query($sql)){
			$_SESSION['success'] = 'Account user Created Successfully!!!';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}	
		header('location:users.php');
		}

?>


<?php
	include 'includes/session.php';
		

	if(isset($_POST['update'])){
		$username = $_POST['username'];
		$pass = $_POST['password'];
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$level = $_POST['level'];
		$photo = $_FILES['photo']['name'];
		$id=$_POST['edit'];
		$password = password_hash($pass, PASSWORD_DEFAULT);
		$sql = "UPDATE users SET username = '$username', password = '$password',level='$level', firstname = '$firstname', lastname = '$lastname', photo = '$filename' WHERE id = '$id'";
		move_uploaded_file($_FILES['photo']['tmp_name'], 'images/'.$photo);
		if($conn->query($sql)){
			$_SESSION['success'] = 'User info updated successfully!!';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
		
		header('location:users.php');
		}

?>
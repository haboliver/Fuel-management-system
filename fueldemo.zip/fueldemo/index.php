<?php
  	session_start();
  	if(isset($_SESSION['admin'])){
    	header('location:home.php');
  	}
?>
<!DOCTYPE html><html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>fuel</title>
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/style.css">
        <link rel="shortcut icon" href="assets/img/RSOG-logo.png">
        </head>
        <body style="background:background-color: #f8f4f4;">
            <div class="main-wrapper account-wrapper">
                <div class="account-page">
                    <div class="account-center">
                        <div class="account-box">
                            <form action="login.php" class="form-signin" method="POST">
                                <div class="account-logo"><a href="index.php">
                                    <img src="images/fuels.png" alt=""style="height:440px;width:440px;"></a>
                                    </div>
                                    <div class="form-group">
                                        <label style="font-size:14px;font-weight:400">Email</label>
                                    <input type="text"  name="username" class="form-control" placeholder="Enter your Email" required>
                                    </div>
                                    <div class="form-group">
                                        <label style="font-size:14px;font-weight:400">Password</label>
                                        <input type="password" name="password" class="form-control" placeholder="xxxxxxxxxxxxxxx" required>
                                        </div>
                                        <!--<div class="form-group text-right">
                                            <a href="forgot-password.html">Forgot your password?</a>
                                            </div>-->
                                            <div class="form-group text-center">
                                                <input type="submit" name="login" value="Login" class="btn btn-primary account-btn w-full" style="width:100%;border-radius:3px;">
                                                </div>
                                                <div class="text-center register-link">                            Forget password? <a href="#">Reset password</a>
                                                </div>
                                                </form>
												<?php
  		if(isset($_SESSION['error'])){
  			echo "
  				<div class='btn btn-danger'>
			  		<p>".$_SESSION['error']."</p> 
			  	</div>
  			";
  			unset($_SESSION['error']);
  		}
  	?>
                                                </div>
                                                </div>
                                                </div>
                                                </div>
                                                <script src="assets/js/jquery-3.2.1.min.js"></script>
                                                <script src="assets/js/popper.min.js"></script>
                                                <script src="assets/js/bootstrap.min.js"></script>
                                                <script src="assets/js/app.js"></script>
                                                </body>
                                                </html>
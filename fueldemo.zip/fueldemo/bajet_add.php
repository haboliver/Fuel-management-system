<?php
	include 'includes/session.php';
	if(isset($_POST['save'])){
	$b=$_POST['balance'];
	if($insert=$conn->query("INSERT INTO `bajets`(`opening_balance`, `open_date`) VALUES ('$b',now())"))
	{
	$update=$conn->query("UPDATE `stocks` SET `opening_balance`=opening_balance +'$b',`open_date`=now()");
	$_SESSION['success']="Bajet added Successfully!!";
	}
	else
	{
	$_SESSION['error'] = $conn->error;
	}
	header('location:badjet.php');
	}
	?>
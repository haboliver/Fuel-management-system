<?php
	include 'includes/session.php';

	if(isset($_POST['save'])){
	$id=$_POST['id'];
	$plate=$_POST['plateno'];
	$model=$_POST['model'];
	$driver=$_POST['driver'];
		$card=$_POST['card'];
	 if($insert=$conn->query("UPDATE `cars` SET `plateno`='$plate',`model`='$model',`driver_id`='$driver',`cardno`='$card',`status`='active' WHERE `car_id`='$id'"))
	{
	$_SESSION['success']="Car info updated Successfully!!";
	}
	else
	{
	$_SESSION['error'] = $conn->error;
	}
	
	header('location:cars.php');
	
	}?>
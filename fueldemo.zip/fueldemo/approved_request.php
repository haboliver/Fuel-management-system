<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Approved Requisition List
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li>Approved fuel</li>
        <li class="active">Approved Req List</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
             
            </div>
            <div class="box-body">
                <table id="example1" class="table table-bordered">
                <thead>
				<th>#</th>
				 <th>Req.Date</th>
                  <th>FullNames</th>
                  <th>KM</th>
                 
				  <th>PlateNo</th>
				  <th>CardNo</th>
				  <th>Model</th>
                  <th>Amount</th>
                  <th>Location</th>
				
                  <th>Tools</th>
                </thead>
                <tbody>
                  <?php
				  $x=1;
                    $sql = "SELECT f.request_id,f.user_id,f.car_id,f.request_date,f.km,f.req_fuel_qty,f.status,f.rec_amount,f.ap_amount,f.comments,f.locations,f.bill,f.approve_reject_level1,f.approve_reject_level2,f.approve_reject_date,f.ap_rej_comments,u.id,u.username,u.phone,u.firstname,u.lastname,u.nid,u.job_title,u.level,u.photo,c.car_id,c.plateno,c.model,c.cardno,c.status as car from fuels_request f LEFT JOIN users u ON f.user_id=u.id LEFT JOIN cars c ON  f.car_id=c.car_id WHERE f.status='approved' AND f.approve_reject_level2<>'' ORDER BY f.request_date DESC";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){?>
					<tr>
					<td><?php echo $x;?></td>
					<td><?php echo $row['request_date'];?></td>
					<td><?php echo $row['firstname']."&nbsp;".$row['lastname'];?></td>
					<td><?php echo $row['km'];?></td>
					
					<td><?php echo $row['plateno'];?></td>
					<td><?php echo $row['cardno'];?></td>
					<td><?php echo $row['model'];?></td>
					<td>Amount Requested:<?php echo number_format($row['rec_amount'],2)."<b>RWF</b>";?><br>
					Approved Amount:<?php echo number_format($row['ap_amount'],2)."<b>RWF</b>";?>
					
					</td>
					<td><?php echo $row['locations'];?></td> 
										 <td>
					 
					 <?php if($row['approve_reject_level1']==''){ 
					 }
					else if($row['approve_reject_level2']=='' && $user['level']=='hr'){
					 echo"<button class='btn btn-success btn-sm approve btn-flat' data-id='".$row['request_id']."'><i class='fa fa-edit'></i>Final Approve</button>
					 <button class='btn btn-danger btn-sm reject btn-flat' data-id='".$row['request_id']."'><i class='fa fa-trash'></i>Reject</button>";
					 }
					 
					 else if($row['approve_reject_level2']!='' && $user['level']=='hr')
					 {
					 echo"requisition approved on".$row['approve_reject_date']."<button class='btn btn-primary btn-sm reject btn-flat' data-id='".$row['request_id']."'><i class='fa fa-eye'></i></button>";
					 }
					 else if($row['approve_reject_level2']!='' && $row['approve_reject_level1']!='' && $user['level']=='hr')
					 {
					 echo "requisition approved on".$row['approve_reject_date']."<button class='btn btn-primary btn-sm reject btn-flat' data-id='".$row['request_id']."'><i class='fa fa-eye'></i></button>";
					 }
					 ?>
                            
                          </td>    
                  </tr>
				  <?php
				  }
				  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
   
  <?php include 'includes/footer.php'; ?>
</div>

<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $(document).on('click', '.approve', function(e){
    e.preventDefault();
    $('#fapprove').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.delete', function(e){
    e.preventDefault();
    $('#reject').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.photo', function(e){
    e.preventDefault();
    var id = $(this).data('id');
    getRow(id);
  });

});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'approve_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('#id').val(response.request_id);
	  $('.id').val(response.request_id);
      $('.driver').html(response.firstname+'&nbsp;'+response.lastname);
	  $('.plate').html(response.plateno);
	  $('.liters').html(response.req_fuel_qty);
	   $('.amount').html(response.total_price);
	   $('#am').val(response.total_price);
	   $('#amount').val(response.rec_amount);
	   $('.model').html(response.model);
    }
  });
}
</script>
<?php include 'includes/approve_modal.php'; ?>  
</body>
</html>

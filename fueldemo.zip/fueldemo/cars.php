<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 align="center">
     List of cars
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li>Transaction</li>
        <li class="active">Cars</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
	 <?php
        if(isset($_SESSION['errors'])){
		echo '<div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-warning"></i> Error!</h4>'.$_SESSION['errors'].'</div>';
			  }
			  unset($_SESSION['errors']); 
          ?>
      <?php
        if(isset($_SESSION['error'])){
          ?>
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-warning"></i> Error!</h4>
                <ul>
                <?php
                  foreach($_SESSION['error'] as $error){
                    echo "
                      <li>".$error."</li>
                    ";
                  }
                ?>
                </ul>
            </div>
          <?php
          unset($_SESSION['error']);
        }

        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
	
              <a href="#newcar" data-toggle="modal" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-car"></i>Add New car</a>
            </div>
            <div class="box-body">
		
		 <div class="modal-content">
          	
          	<div class="modal-body">
            	
				<style>
img {
  border-radius: 60%;
}
</style>

              <table id="table" class="table table-bordered">
                <thead>
        
                  <th>#</th>
                  <th>Driver Names</th>
                 <th>Plate Number</th>
                  <th>Car Model</th>
                  <th>Fuel Card Number</th>
				 <th>Status</th>
				  <th>Actions</th>
                
                </thead>
                <tbody>
				<?php
                    $sql = "SELECT u.id,u.username,u.phone,u.password,u.firstname,u.lastname,u.nid,u.job_title,u.level,u.photo,c.car_id,c.plateno,c.model,c.cardno,c.driver_id,c.status FROM cars c LEFT JOIN users u ON c.driver_id=u.id";
					$x=1;
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){?>
                
                    <tr>
                  <td><?php echo $x;?></td>
				  <td><?php echo $row['firstname'];?>&nbsp;<?php echo $row['lastname'];?></td>
		
				  <td><?php echo $row['plateno'];?></td>
          <td><?php echo $row['model'];?></td>
          <td><?php echo $row['cardno'];?></td>
				 
				  <td><?php echo $row['status'];?></td>
				   <td>
				   <?php echo "<button class='btn btn-success btn-sm edit btn-flat' data-id='".$row['car_id']."'><i class='fa fa-edit'></i> Edit</button>&nbsp;    <button class='btn btn-danger btn-sm delete btn-flat' data-id='".$row['car_id']."'><i class='fa fa-trash'></i> Delete</button>";?>
				   </td>
         </tr>
                
				<?php
				$x++;
				}
				?>
				</tbody>
              </table>
			 
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
   <script src="java_file/jquery-3.2.1.js"></script>
<script src = "java_file/jquery.dataTables.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		$('#table').DataTable();
	});
</script>
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/car_modal.php'; ?>

<?php include 'includes/scripts.php'; ?>
 <script>
$(function(){
  $(document).on('click', '.edit', function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.delete', function(e){
    e.preventDefault();
    $('#delete').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.photo', function(e){
    e.preventDefault();
    var car_id = $(this).data('car_id');
    getRow(car_id);
  });

});

function getRow(car_id){
  $.ajax({
    type: 'POST',
    url: 'cars_row.php',
    data: {car_id:car_id},
    dataType: 'json',
    success: function(response){
      $('.id').val(response.car_id);
      $('#plateno').val(response.plateno);
      $('#model').val(response.model);
      $('#driver').val(response.driver_id);
      $('#card').val(response.cardno);
	   $('.del').html(response.plateno+' '+response.model);
	
    }
  });
}
</script>

</body>
</html>

<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Responce List
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li>Responce</li>
        <li class="active">Responce List</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
            
            </div>
            <div class="box-body">
                <table id="example1" class="table table-bordered">
                <thead>
				<th>#</th>
				 <th>Req.Date</th>
                  <th>FullNames</th>
                  <th>KM</th>
                 
				  <th>PlateNo</th>
				  <th>CardNo</th>
				  <th>Model</th>
                  <th>Approved amount</th>
                  <th>Location</th>
				
                  <th>Tools</th>
                </thead>
                <tbody>
                  <?php
				  $x=1;
                    $sql = "SELECT f.request_id,f.user_id,f.car_id,f.request_date,f.km,f.req_fuel_qty,f.status,f.ap_amount,f.comments,f.locations,f.bill,f.approve_reject_level1,f.approve_reject_level2,f.approve_reject_date,f.ap_rej_comments,u.id,u.username,u.phone,u.firstname,u.lastname,u.nid,u.job_title,u.level,u.photo,c.car_id,c.plateno,c.model,c.cardno,c.status as car from fuels_request f LEFT JOIN users u ON f.user_id=u.id LEFT JOIN cars c ON  f.car_id=c.car_id WHERE f.user_id='$user[id]' ORDER BY f.request_date DESC";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){?>
					<tr>
					<td><?php echo $x;?></td>
					<td><?php echo $row['request_date'];?></td>
					<td><?php echo $row['firstname']."&nbsp;".$row['lastname'];?></td>
					<td><?php echo $row['km'];?></td>
					
					<td><?php echo $row['plateno'];?></td>
					<td><?php echo $row['cardno'];?></td>
					<td><?php echo $row['model'];?></td>
					<td><?php if($row['ap_amount']==0 && $row['status']=='rejected'){ echo"<b><i class='fa fa-close'></i>Rejected</b>";} else
					{echo number_format($row['ap_amount'],2)."<b>RWF</b>";}?></td>
					<td><?php echo $row['locations'];?></td>
					 <td>
					
                           <?php 
						   if($row['status']=='approved' && $row['approve_reject_level1']!='')
						   {
						   echo "in Process";
						   }
						  	else if($row['approve_reject_level1']!='' && $row['approve_reject_level2']!='' && $row['status']=='approved'){
						  
						   echo "Your Requisition is approved , upload your bill<br><button class='btn btn-success btn-sm edit btn-flat' data-id='".$row['request_id']."'><i class='fa fa-edit'></i> </button>";
						   }
						   else if($row['approve_reject_level1']!='' && $row['approve_reject_level2']!='' && $row['status']=='rejected'){
						       echo "<b><i class='fa fa-close'></i>Rejected</b>";
						   }
						   else
						   {
						   echo "pending";
						   }
						   ?>
                          </td>    
                  </tr>
				  <?php
				  }
				  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
   
  <?php include 'includes/footer.php'; ?>
</div>

<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $(document).on('click', '.edit', function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.delete', function(e){
    e.preventDefault();
    $('#delete').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.photo', function(e){
    e.preventDefault();
    var id = $(this).data('id');
    getRow(id);
  });

});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'student_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('.studid').val(response.studid);
      $('#edit_firstname').val(response.firstname);
      $('#edit_lastname').val(response.lastname);
      $('#selcourse').val(response.course_id);
      $('#selcourse').html(response.code);
      $('.del_stu').html(response.firstname+' '+response.lastname);
    }
  });
}
</script>
<?php include 'includes/req_modal.php'; ?> 
</body>
</html>

<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 align="center">
     List of system users
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li>Transaction</li>
        <li class="active">Users</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          ?>
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-warning"></i> Error!</h4>
                <ul>
                <?php
                  foreach($_SESSION['error'] as $error){
                    echo "
                      <li>".$error."</li>
                    ";
                  }
                ?>
                </ul>
            </div>
          <?php
          unset($_SESSION['error']);
        }

        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
			<?php
if(!isset($_POST['module']))
{
?>
              <a href="#users" data-toggle="modal" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-plus"></i>Add New User</a><?php }?>
            </div>
            <div class="box-body">
		
		 <div class="modal-content">
          	
          	<div class="modal-body">
            	
				<style>
img {
  border-radius: 60%;
}
</style>

              <table id="table" class="table table-bordered">
                <thead>
        
                  <th>#</th>
                  <th>FullNames</th>
                 <th>Email</th>
                  <th>Phone</th>
				
			
				  <th>Image</th>
			
				 <th>Level</th>
				  <th>buttons</th>
                
                </thead>
                <tbody>
				<?php
                    $sql = "SELECT * FROM users WHERE level <>'admin'";
					$x=1;
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){?>
                
                    <tr>
                  <td><?php echo $x;?></td>
				  <td><?php echo $row['firstname'];?>&nbsp;<?php echo $row['lastname'];?></td>
		
				  <td><?php echo $row['username'];?></td>
          <td><?php echo $row['phone'];?></td>
				 
				  <td><img src="<?php if(!empty($row['photo'])){ echo 'images/'.$row['photo'];} else{ echo 'images/profile.jpg';} ?>"alt='Avatar' style='width:60px'></td>
				  <td><?php if($row['level']=='admin'){ echo "System administrator";} else if($row['level']=='admins'){ echo "System admin";} else if($row['level']=='driver'){ echo "Driver";} else if($row['level']=='hr'){ echo "Human Ressource";}else if($row['level']=='logistic'){ echo "Logistic";}else if($row['level']=='cordinator'){ echo "SPIU Coordinator";} ?></td>
				   <td>
				   <?php echo "<button class='btn btn-success btn-sm edit btn-flat' data-id='".$row['id']."'><i class='fa fa-edit'></i> Edit</button>&nbsp;    <button class='btn btn-danger btn-sm delete btn-flat' data-id='".$row['id']."'><i class='fa fa-trash'></i> Delete</button>";?>
				   </td>
         </tr>
                
				<?php
				$x++;
				}
				?>
				</tbody>
              </table>
			 
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
   <script src="java_file/jquery-3.2.1.js"></script>
<script src = "java_file/jquery.dataTables.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		$('#table').DataTable();
	});
</script>
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/myuser_modal.php'; ?>

<?php include 'includes/scripts.php'; ?>
 <script>
$(function(){
  $(document).on('click', '.edit', function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.delete', function(e){
    e.preventDefault();
    $('#delete').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.photo', function(e){
    e.preventDefault();
    var id = $(this).data('id');
    getRow(id);
  });

});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'users_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('.id').val(response.id);
      $('#edit_firstname').val(response.firstname);
      $('#edit_lastname').val(response.lastname);
      $('#phone').val(response.phone);
      $('#level').val(response.level);
	  $('#email').val(response.username);
     $('#level').val(response.level);
	  $('.del').html(response.firstname+' '+response.lastname);
	
    }
  });
}
</script>

</body>
</html>

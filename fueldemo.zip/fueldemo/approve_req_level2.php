<?php
	include 'includes/session.php';

	if(isset($_POST['update'])){
		$id = $_POST['id'];
		$comment=$_POST['comment'];
		$user=$_POST['user'];
		$amount=$_POST['amount'];
		if($delete=$conn->query("UPDATE `fuels_request` SET `approve_reject_level2`='$user approved',	`approve_reject_date`=now(),`ap_rej_comments`='$comment',`status`='approved',`ap_amount`='$amount' WHERE `request_id`='$id'"))
		{
	$update=$conn->query("UPDATE `stocks` SET `opening_balance`=opening_balance-'$amount'");
	$close=$conn->query("UPDATE `stocks` SET `clasing_balance`=opening_balance,`clasing_date`=now()");
			$_SESSION['success'] = 'Requisition approved on level 2 successfully!!';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	
	header('location:approved_request.php');
	}
?>
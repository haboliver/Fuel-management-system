<?php 
	include 'includes/session.php';

	if(isset($_POST['car_id'])){
		$id = $_POST['car_id'];
		$sql = "SELECT * FROM `cars` WHERE `car_id`='$id'";
		$query = $conn->query($sql);
		$row = $query->fetch_assoc();

		echo json_encode($row);
	}
?>
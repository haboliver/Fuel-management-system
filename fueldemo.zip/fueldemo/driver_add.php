<?php
	include 'includes/session.php';

	if(isset($_POST['save'])){
	
		$username = $_POST['username'];
		$phone = $_POST['phone'];
		$pass = $_POST['password'];
		$firstname = $_POST['firstname'];
		$level = $_POST['level'];
		$lastname = $_POST['lastname'];
		$nid = $_POST['nid'];
		$job = $_POST['job'];
		$licence = $_POST['licence'];
		$exp = $_POST['exp'];
		$photo = $_FILES['photo']['name'];
		$password = password_hash($pass, PASSWORD_DEFAULT);
	
		move_uploaded_file($_FILES['photo']['tmp_name'], 'images/'.$photo);
			$sql = "INSERT INTO `users`( `username`, `phone`, `password`, `firstname`, `lastname`, `nid`, `job_title`, `level`, `driving_licence`, `exp_date`) VALUES ('$username','$phone','$password','$firstname','$lastname','$nid','$job','$level','$licence','$exp')";
			if($conn->query($sql)){
			$_SESSION['success'] = 'Account user Created Successfully!!!';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}

		header('location:drivers.php');
		}

?>


<?php
	include 'includes/session.php';
		

	if(isset($_POST['update'])){
		$username = $_POST['username'];
		$pass = $_POST['password'];
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$level = $_POST['level'];
		$photo = $_FILES['photo']['name'];
		$id=$_POST['edit'];
		$password = password_hash($pass, PASSWORD_DEFAULT);
		$sql = "UPDATE users SET username = '$username', password = '$password',level='$level', firstname = '$firstname', lastname = '$lastname', photo = '$filename' WHERE id = '$id'";
		move_uploaded_file($_FILES['photo']['tmp_name'], 'images/'.$photo);
		if($conn->query($sql)){
			$_SESSION['success'] = 'User info updated successfully!!';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
		
		header('location:users.php');
		}

?>
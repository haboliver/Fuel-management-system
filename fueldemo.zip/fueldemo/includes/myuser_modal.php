<!-- Add -->
<div class="modal fade" id="users">
    <div class="modal-dialog">
        <div class="modal-content">
          	<div class="modal-header">
            	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
              		<span aria-hidden="true">&times;</span></button>
            	<h4 class="modal-title"><b>Add New user</b></h4>
          	</div>
          	<div class="modal-body">
            	<form class="form-horizontal" method="POST" action="user_add.php" enctype="multipart/form-data">
          		  <div class="form-group">
                  	<label for="username" class="col-sm-3 control-label">Email</label>

                  	<div class="col-sm-9">
                    	<input type="text" class="form-control" id="username" name="username" placeholder="Enter user Email.." required>
                  	</div>
                </div>
                <div class="form-group">
                    <label for="username" class="col-sm-3 control-label">Phone number</label>

                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="username" name="phone" placeholder="Enter user phone.." required>
                    </div>
                </div>
				  <div class="form-group">
                  	<label for="username" class="col-sm-3 control-label">User Level</label>

                  	<div class="col-sm-9">
                    	<select name="level" class="form-control" required><option value="">[select level]</option>
						<option value="admins">admins</option>
						<option value="hr">Human Ressourc</option>
						<option value="driver">Driver</option>
						<option value="logistic">Logistic</option>
						<option value="cordinator">SPIU Coordinator</option>
						</select>
                  	</div>
                </div>
				
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>

                    <div class="col-sm-9"> 
                      <input type="password" class="form-control" id="password" name="password" placeholder="Password.."  required>
                    </div>
                </div>
				 
                <div class="form-group">
                  	<label for="firstname" class="col-sm-3 control-label">First Name</label>

                  	<div class="col-sm-9">
                    	<input type="text" class="form-control" id="firstname" name="firstname"  placeholder="Enter First Name.." required>
                  	</div>
                </div>
                <div class="form-group">
                  	<label for="lastname" class="col-sm-3 control-label">Last Name</label>

                  	<div class="col-sm-9">
                    	<input type="text" class="form-control" id="lastname" name="lastname" placeholder="Enter your Lastname.."   required/>
                  	</div>
                </div>
				
                <div class="form-group">
                    <label for="photo" class="col-sm-3 control-label">Profile image:</label>

                    <div class="col-sm-9">
                      <input type="file" id="photo" name="photo">
                    </div>
                </div>
                <hr>
               
          	</div>
          	<div class="modal-footer">
            	<button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
            	<button type="submit" class="btn btn-success btn-flat" name="save"><i class="fa fa-check-square-o"></i> Save</button>
            	</form>
          	</div>
        </div>
    </div></div>
	
	
	
	
	
	<div class="modal fade" id="driver">
    <div class="modal-dialog">
        <div class="modal-content">
          	<div class="modal-header">
            	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
              		<span aria-hidden="true">&times;</span></button>
            	<h4 class="modal-title"><b>Add New  Driver</b></h4>
          	</div>
          	<div class="modal-body">
            	<form class="form-horizontal" method="POST" action="driver_add.php" enctype="multipart/form-data">
          		  <div class="form-group">
                  	<label for="username" class="col-sm-3 control-label">Email</label>

                  	<div class="col-sm-9">
                    	<input type="text" class="form-control" id="username" name="username" placeholder="Enter user Email.." required>
                  	</div>
                </div>
                <div class="form-group">
                    <label for="username" class="col-sm-3 control-label">Phone number</label>

                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="username" name="phone" placeholder="Enter user phone.." required>
                    </div>
                </div>
				
				<div class="form-group">
                    <label for="username" class="col-sm-3 control-label">ID No</label>

                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="username" name="nid" maxlength="16" placeholder="Enter ID No.." required>
                    </div>
                </div>
				
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>

                    <div class="col-sm-9"> 
                      <input type="password" class="form-control" id="password" name="password" placeholder="Password.."  required>
					  <input type="hidden" name="level" value="driver" class="form-control" required>
                    </div>
                </div>
				 
                <div class="form-group">
                  	<label for="firstname" class="col-sm-3 control-label">First Name</label>

                  	<div class="col-sm-9">
                    	<input type="text" class="form-control" id="firstname" name="firstname"  placeholder="Enter First Name.." required>
                  	</div>
                </div>
                <div class="form-group">
                  	<label for="lastname" class="col-sm-3 control-label">Last Name</label>

                  	<div class="col-sm-9">
                    	<input type="text" class="form-control" id="lastname" name="lastname" placeholder="Enter your Lastname.."   required/>
                  	</div>
                </div>
				 <div class="form-group">
                  	<label for="lastname" class="col-sm-3 control-label">Licence</label>

                  	<div class="col-sm-9">
                    	<select class="form-control" name="licence" required>
						<option value="">--Select Category--</option>
						<option value="A">--A--</option>
						<option value="B">--B--</option>
						<option value="C">--C--</option>
						<option value="D">--C--</option>
						<option value="F">--F--</option></select>
                  	</div>
                </div>
				 <div class="form-group">
                  	<label for="lastname" class="col-sm-3 control-label">Exp.Date</label>

                  	<div class="col-sm-9">
                    	<input type="date" class="form-control"  name="exp"   required/>
                  	</div>
                </div>
				
                <div class="form-group">
                    <label for="photo" class="col-sm-3 control-label">Profile image:</label>

                    <div class="col-sm-9">
                      <input type="file" id="photo" name="photo">
                    </div>
                </div>
                <hr>
               
          	</div>
          	<div class="modal-footer">
            	<button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
            	<button type="submit" class="btn btn-success btn-flat" name="save"><i class="fa fa-check-square-o"></i> Save</button>
            	</form>
          	</div>
        </div>
    </div></div>
	
	
	
	
		
	<div class="modal fade" id="edit_driver">
    <div class="modal-dialog">
        <div class="modal-content">
          	<div class="modal-header">
            	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
              		<span aria-hidden="true">&times;</span></button>
            	<h4 class="modal-title"><b>Edit Driver Record</b></h4>
          	</div>
          	<div class="modal-body">
            	<form class="form-horizontal" method="POST" action="driver_edit.php" enctype="multipart/form-data">
          		  <div class="form-group">
                  	<label for="username" class="col-sm-3 control-label">Email</label>

                  	<div class="col-sm-9">
					<input type="text" name="id" class="id" />
                    	<input type="text" class="form-control" id="email" name="username" placeholder="Enter user Email.." required>
                  	</div>
                </div>
                <div class="form-group">
                    <label for="username" class="col-sm-3 control-label">Phone number</label>

                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter user phone.." required>
                    </div>
                </div>
				
				<div class="form-group">
                    <label for="username" class="col-sm-3 control-label">ID No</label>

                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="nid" name="nid" maxlength="16" placeholder="Enter ID No.." required>
                    </div>
                </div>
				
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>

                    <div class="col-sm-9"> 
                      <input type="password" class="form-control" id="password" name="password" placeholder="Password.."  required>
					
                    </div>
                </div>
				 
                <div class="form-group">
                  	<label for="firstname" class="col-sm-3 control-label">First Name</label>

                  	<div class="col-sm-9">
                    	<input type="text" class="form-control" id="firstname" name="firstname"  placeholder="Enter First Name.." required>
                  	</div>
                </div>
                <div class="form-group">
                  	<label for="lastname" class="col-sm-3 control-label">Last Name</label>

                  	<div class="col-sm-9">
                    	<input type="text" class="form-control" id="lastname" name="lastname" placeholder="Enter your Lastname.."   required/>
                  	</div>
                </div>
				 <div class="form-group">
                  	<label for="lastname" class="col-sm-3 control-label">Licence</label>

                  	<div class="col-sm-9">
                    	<input type="text" class="form-control" id="licence" name="licence" required>
					
                  	</div>
                </div>
				 <div class="form-group">
                  	<label for="lastname" class="col-sm-3 control-label">Exp.Date</label>

                  	<div class="col-sm-9">
                    	<input type="date" class="form-control" id="exp"  name="exp"   required/>
                  	</div>
                </div>
				
                <div class="form-group">
                    <label for="photo" class="col-sm-3 control-label">Profile image:</label>

                    <div class="col-sm-9">
                      <input type="file" id="photo" name="photo">
                    </div>
                </div>
                <hr>
               
          	</div>
          	<div class="modal-footer">
            	<button type="submit" class="btn btn-success btn-flat" name="update"><i class="fa fa-check-square-o"></i>Update</button>
            	</form>
          	</div>
        </div>
    </div></div>
	
	
	
	
	
	<div class="modal fade" id="edit">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"><b>Edit System User</b></h4>
            </div>
            <div class="modal-body">
              <form class="form-horizontal" method="POST" action="<?php if($user['level']=='customer' ||$user['level']=='technician')
				{echo "edit_info.php";} else{ echo "users_edit.php";}?>" enctype="multipart/form-data">
                <input type="hidden" class="id" name="id">
                <div class="form-group">
                    <label for="edit_firstname" class="col-sm-3 control-label">Firstname</label>

                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="edit_firstname" name="firstname">
                    </div>
                </div>
                <div class="form-group">
                    <label for="edit_lastname" class="col-sm-3 control-label">Lastname</label>

                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="edit_lastname" name="lastname">
                    </div>
                </div>
                <div class="form-group">
                    <label for="course" class="col-sm-3 control-label">Phone</label>

                    <div class="col-sm-9">
                     <input type="text" class="form-control" id="phone" name="phone" maxlength="10" required>
                      
                    </div>
                </div>
				 <div class="form-group">
                    <label for="course" class="col-sm-3 control-label">Email ID</label>

                    <div class="col-sm-9">
                     <input type="text" class="form-control" id="email" name="email" required>
                      
                    </div>
                </div>
				 <div class="form-group">
                    <label for="course" class="col-sm-3 control-label">National ID</label>

                    <div class="col-sm-9">
                     <input type="text" class="form-control" id="nid" name="nid" maxlength="16" required>
                      
                    </div>
                </div>
				 <div class="form-group">
                    <label for="course" class="col-sm-3 control-label">Password</label>

                    <div class="col-sm-9">
                     <input type="password" class="form-control" placeholder="xxxxxxxxxxxx"  name="password" required>
                      
                    </div>
                </div><?php if($user['level']=='customer' ||$user['level']=='technician' ||$user['level']=='admin')
				{
				echo "<input type='hidden' name='level' id='level'>";
				}
				else
				{?>
				 <div class="form-group">
                    <label for="course" class="col-sm-3 control-label">Level</label>

                    <div class="col-sm-9">
                   <select class="form-control" id="level" name="level" required>
                        <option value="" selected id="level"></option>
                      <option>admins</option>
					  <option>customer</option>
					  <option>technician</option>
					  <option>branch manager</option>
                      </select>
                      
                    </div>
                </div>
				<?php
				}
				?>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
              <button type="submit" class="btn btn-success btn-flat" name="edit"><i class="fa fa-check-square-o"></i> Update</button>
              </form>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="delete">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"><b>Deleting...</b></h4>
            </div>
            <div class="modal-body">
              <form class="form-horizontal" method="POST" action="users_delete.php">
                <input type="hidden" class="id" name="id">
                <div class="text-center">
                    <p>Are you Sure you want to delete this account?</p>
                    <h2 class="del bold"></h2>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i>No</button>
              <button type="submit" class="btn btn-danger btn-flat" name="delete"><i class="fa fa-trash"></i> Yes</button>
              </form>
            </div>
        </div>
    </div>
</div>

<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image">
        <img src="<?php echo (!empty($user['photo'])) ? 'images/'.$user['photo'] : 'images/profile.jpg'; ?>" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p><?php echo $user['firstname'].' '.$user['lastname']; ?></p>
        <a><i class="fa fa-circle text-success"></i> Online</a>
      </div>
    </div>
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header">REPORTS</li>
      <li class=""><a href="home.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
      <li class="header">MANAGE</li>
	  <?php
	  if($user['level']=='admin')
	  {
	  ?>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-users"></i>
          <span>Manage users</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="users.php"><i class="fa fa-circle-o"></i> View Users </a></li>
          
        </ul>
      </li>
	  <?php
	  }
	  ?>
	    <?php
	  if($user['level']=='admin')
	  {
	  ?>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-car"></i>
          <span>Manage Cars</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="cars.php"><i class="fa fa-circle-o"></i>View Cars </a></li>
         
        </ul>
      </li>
	  <?php
	  }
	  ?>
	    <?php
	  if($user['level']=='admin')
	  {
	  ?>
      <li class="treeview">
        <a href="#">
          <i class="fa fa-id-card"></i>
          <span>Manage drivers</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="drivers.php"><i class="fa fa-circle-o"></i>  View Drivers </a></li>
        
        </ul>
      </li>
	  <?php
	  }
	  ?>
	  
	    <li class="treeview">
        <a href="#">
         <i class="fa fa-gear"></i>
          <span>Manage request</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
		  <?php
	  if($user['level']=='driver')
	  {
	  ?>
          <li><a href="request_fules.php"><i class="fa fa-circle-o"></i> View Fuel request </a></li>
		  
		   <li><a href="inbox.php"><i class="fa fa-circle-o"></i>Response</a></li>
		   
		   <?php 
		   }
		   ?>
		     <?php
	  if($user['level']=='admin' || $user['level']=='hr' ||$user['level']=='logistic' ||$user['level']=='cordinator')
	  {
	  ?>
		    <li><a href="incoming_request.php"><i class="fa fa-circle-o"></i>Incoming request</a></li>
			 <li><a href="approved_request.php"><i class="fa fa-circle-o"></i>Approved request</a></li>
			  <li><a href="rejected_request.php"><i class="fa fa-circle-o"></i>Rejected Request</a></li>
			  <?php
			  }
			  ?>
        
        </ul>
      </li>
	    <?php
	  if($user['level']=='admin' || $user['level']=='hr' ||$user['level']=='logistic'||$user['level']=='cordinator')
	  {
	  ?>
	      <li class="treeview">
        <a href="#">
          <i class="glyphicon glyphicon-stats"></i>
          <span>Reports</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="reports.php"><i class="fa fa-circle-o"></i>Generate Reports</a></li>
		  
        
        </ul>
      </li>
	  <?php
	  }
	  ?>
	  
	   </li>
	    <?php
	  if($user['level']=='admin')
	  {
	  ?>
	      <li class="treeview">
        <a href="#">
          <i class="fa fa-gears"></i>
          <span>Settings</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li><a href="badjet.php"><i class="fa fa-circle-o"></i>Manage Fuel Budget</a></li>
		  
        
        </ul>
      </li>
	  <?php
	  }
	  ?>
	  
	  
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>
<!-- Add -->
<div class="modal fade" id="bajet">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"><b>Add New bajet</b></h4>
            </div>
            <div class="modal-body">
              <form class="form-horizontal" method="POST" action="bajet_add.php">
                <div class="form-group">
                    <label for="code" class="col-sm-3 control-label">Balance</label>

                    <div class="col-sm-9">
                      <input type="text" class="form-control" placeholder="numbers only" id="balance" name="balance" required>
                    </div>
                </div>
               
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
              <button type="submit" class="btn btn-primary btn-flat" name="save"><i class="fa fa-save"></i> Add</button>
              </form>
            </div>
        </div>
    </div>
</div>
<!-- Add -->
<div class="modal fade" id="reject">
    <div class="modal-dialog">
        <div class="modal-content">
          	<div class="modal-header">
            	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
              		<span aria-hidden="true">&times;</span></button>
            	<h4 class="modal-title"><b>Continue Rejecting  Requisition........</b></h4>
          	</div>
          	<div class="modal-body">
            	<form class="form-horizontal" method="POST" action="reject_request1.php">
				
          		  <div class="form-group">
                  <div class="text-center">
				  <input type="hidden" name="id" id="id" />
				  <input type="hidden" name="user" value="<?php echo $user['level'];?>" />
	                	<h2>Are you sure you want to Reject this Requisition?</h2>
	                <p>PlateNo:<i class="plate"></i></p>
					<p>Model:<i class="model"></i></p>
					<p>CardNo:<i class="card"></i></p>
					<p>Driver Name:<i class="driver"></i></p>
					<p>Liter:<i class="liters"></i>Liters</p>
					<p>Amount Requested:<input type="text" name="amount" class="amount"></i>RWF</p>
					
					<textarea rows="4" cols="20" name="comment"  class="form-control" placeholder="type comment..." required></textarea>
	            	</div>
                </div>
               
                         	<div class="modal-footer">
            	<button type="button" class="btn btn-danger btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i>Cancel</button>
            	<button type="submit" class="btn btn-primary btn-flat" name="reject"><i class="fa fa-check"></i>continue reject</button>
            	</form>
          	</div>
        </div>
    </div>
</div>
</div>


<!-- Add -->
<div class="modal fade" id="fapprove">
    <div class="modal-dialog">
        <div class="modal-content">
          	<div class="modal-header">
            	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
              		<span aria-hidden="true">&times;</span></button>
            	<h4 class="modal-title"><b>Final Approve  Requisition........</b></h4>
          	</div>
          	<div class="modal-body">
            	<form class="form-horizontal" method="POST" action="approve_req_level2.php">
				
          		  <div class="form-group">
                  <div class="text-center">
				  <input type="hidden" name="id" id="id"/>
				  <input type="hidden" name="user" value="<?php echo $user['level'];?>" />
	                	<h2>Are you sure you want to approve this Requisition?</h2>
	                <p>PlateNo:<i class="plate"></i></p>
					<p>Model:<i class="model"></i></p>
					<p>CardNo:<i class="card"></i></p>
					<p>Driver Name:<i class="driver"></i></p>
					<p>Liter:<i class="liters"></i>Liters</p>
					<p>Amount Requested:
					<input type="text" name="amount" class="amount">RWF</p>
					<textarea rows="4" cols="20" name="comment" class="form-control" placeholder="type comment..." required></textarea>
	            	</div>
                </div>
               
                         	<div class="modal-footer">
            	<button type="button" class="btn btn-danger btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i>No</button>
            	<button type="submit" class="btn btn-primary btn-flat" name="update"><i class="fa fa-check"></i>Yes</button>
            	</form>
          	</div>
        </div>
    </div>
</div>

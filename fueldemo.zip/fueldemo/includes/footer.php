<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2022-<?php echo date('Y');?> <a href="#">Fuels V 1.0</a></strong>
</footer>
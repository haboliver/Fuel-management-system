<!-- Add -->
<div class="modal fade" id="edit">
   <div class="modal-dialog">
        <div class="modal-content">
          	<div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              		<span aria-hidden="true"  class="btn btn-danger"><font color="#FF0000" size="+6">&times;</font></span></button>
            	<h4 class="modal-title" align="center"><b>Edit Car info</b></h4>
          	</div>
          	<div class="modal-body">
            	<form class="form-horizontal" method="POST" action="edit_car.php" enctype="multipart/form-data">
          		
				 <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Plate No</label>
<input type="hidden" name="id" class="id" />
                    <div class="col-sm-9"> 
                      <input type="text" class="form-control" id="plateno"  name="plateno" placeholder="Enter Plate No"  required>
                    </div>
                </div>
				 
				 <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Model</label>

                    <div class="col-sm-9"> 
                      <input type="text" class="form-control" id="model"  name="model" placeholder="Enter Model ."  required>
                    </div>
                </div>
				 <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">CardNo</label>

                    <div class="col-sm-9"> 
                      <input type="text" class="form-control" id="card"  name="card" placeholder="Enter Card No ."  required>
                    </div>
                </div>
				  <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Driver</label>

                    <div class="col-sm-9"> 
                     <select name="driver" class="form-control" required>
					 <option value="">---Select Driver--</option>
					 <?php
					 $sql=$conn->query("SELECT * FROM `users` WHERE `level`='driver'");
					 foreach($sql as $row)
					 {
					 ?><option value="<?php echo $row['id'];?>"><?php echo $row['firstname']."&nbsp;".$row['lastname'];?></option>
					 <?php
					 }
					 ?>
					 </select>
                    </div>
                </div>
				 			
                  
          	<div class="modal-footer">
            	
            	<button type="submit" class="btn btn-success btn-flat" name="save"><i class="fa fa-check-square-o"></i>Update car info</button>
            	</form>
          	</div>
        </div>
    </div></div>
	
	</div>
	
	<!-- Add -->
<div class="modal fade" id="newcar">
   <div class="modal-dialog">
        <div class="modal-content">
          	<div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              		<span aria-hidden="true"  class="btn btn-danger"><font color="#FF0000" size="+6">&times;</font></span></button>
            	<h4 class="modal-title" align="center"><b>Record New Car</b></h4>
          	</div>
          	<div class="modal-body">
            	<form class="form-horizontal" method="POST" action="add_car.php" enctype="multipart/form-data">
          		
				 <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Plate NoMM</label>

                    <div class="col-sm-9"> 
                      <input type="text" class="form-control" id="plateno"  name="plateno" placeholder="Enter Plate No"  required>
                    </div>
                </div>
				 
				 <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Model</label>

                    <div class="col-sm-9"> 
                      <input type="text" class="form-control" id="model"  name="model" placeholder="Enter Model ."  required>
                    </div>
                </div>
				 <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">CardNo</label>

                    <div class="col-sm-9"> 
                      <input type="text" class="form-control" id="card"  name="card" placeholder="Enter Model ."  required>
                    </div>
                </div>
				  <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Driver</label>

                    <div class="col-sm-9"> 
                     <select name="driver" class="form-control" required>
					 <option value="">---Select Driver--</option>
					 <?php
					 $sql=$conn->query("SELECT * FROM `users` WHERE `level`='driver'");
					 foreach($sql as $row)
					 {
					 ?><option value="<?php echo $row['id'];?>"><?php echo $row['firstname']."&nbsp;".$row['lastname'];?></option>
					 <?php
					 }
					 ?>
					 </select>
                    </div>
                </div>
				 			
                  
          	<div class="modal-footer">
            	
            	<button type="submit" class="btn btn-success btn-flat" name="save"><i class="fa fa-check-square-o"></i> Save</button>
            	</form>
          	</div>
        </div>
    </div></div>
	</div>
	
	

<div class="modal fade" id="delete">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"><b>Deleting...</b></h4>
            </div>
            <div class="modal-body">
              <form class="form-horizontal" method="POST" action="car_delete.php">
                <input type="hidden" class="id" name="id">
                <div class="text-center">
                    <p>Are you Sure you want to delete this car info?</p>
                    <h2 class="del bold"></h2>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i>No</button>
              <button type="submit" class="btn btn-danger btn-flat" name="delete"><i class="fa fa-trash"></i> Yes</button>
              </form>
            </div>
        </div>
    </div>
</div>

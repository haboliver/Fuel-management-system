<?php 
	include 'includes/session.php';

	if(isset($_POST['id'])){
		$id = $_POST['id'];
		$sql = "SELECT f.request_id,f.user_id,f.car_id,f.request_date,f.km,f.req_fuel_qty,f.total_price,f.rec_amount,f.ap_amount,f.unit_price,f.status,f.comments,f.locations,f.bill,f.approve_reject_level1,f.approve_reject_level2,f.approve_reject_date,f.ap_rej_comments,u.id,u.username,u.phone,u.firstname,u.lastname,u.nid,u.job_title,u.level,u.photo,c.car_id,c.plateno,c.model,c.cardno,c.status as car from fuels_request f LEFT JOIN users u ON f.user_id=u.id LEFT JOIN cars c ON  f.car_id=c.car_id WHERE  f.request_id='$id'";
		$query = $conn->query($sql);
		$row = $query->fetch_assoc();

		echo json_encode($row);
	}
?>
<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 align="center">
    Reports
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li>Transaction</li>
        <li class="active">Reports</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
	 <?php
        if(isset($_SESSION['errors'])){
		echo '<div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-warning"></i> Error!</h4>'.$_SESSION['errors'].'</div>';
			  }
			  unset($_SESSION['errors']); 
          ?>
      <?php
        if(isset($_SESSION['error'])){
          ?>
            <div class="alert alert-danger alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-warning"></i> Error!</h4>
                <ul>
                <?php
                  foreach($_SESSION['error'] as $error){
                    echo "
                      <li>".$error."</li>
                    ";
                  }
                ?>
                </ul>
            </div>
          <?php
          unset($_SESSION['error']);
        }

        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
	
            
            </div>
            <div class="box-body">
		
		 <div class="modal-content">
          	
          	<div class="modal-body">
            	
		
		
<div class="card card-outline card-primary">
	<div class="card-header">
	
        <div class="card-tools">
			<!--<button type="button" class="btn btn-flat btn-success" id="print"><span class="fa fa-print"></span>  Print</button>-->
		</div>
	</div>
	<div class="card-body">
		<fieldset>
			<legend class="text-info">Filter Date Range</legend>
			<form action="" method="POST">
				<div class="row align-items-end">
					<div class="col-md-4">
						<div class="form-group">
							<label for="date_from" class="control-label text-info">From</label>
							<input type="date" id="from" name="from" class="form-control form-control-sm rounded-0" required>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label for="date_to" class="control-label text-info">To</label>
							<input type="date" id="to" name="to" class="form-control form-control-sm rounded-0"  required>
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<button class="btn btn-flat btn-sm btn-primary" name="filter"><i class="fa fa-filter"></i> Filter</button>
						</div>
					</div>
				</div>
			</form>
		</fieldset>
		<div id="print_out">
		<style>
			.img-avatar{
				width:45px;
				height:45px;
				object-fit:cover;
				object-position:center center;
				border-radius:100%;
			}
		</style>
        <div class="container-fluid">
			<table id="example1" class="table table-bordered">
                <thead>
				<th>#</th>
				 <th>Req.Date</th>
                  <th>FullNames</th>
                  <th>KM</th>
                 
				  <th>PlateNo</th>
				  <th>CardNo</th>
				  <th>Model</th>
                  <th>Amount</th>
                  <th>Location</th>
				
                  <th>Tools</th>
                </thead>
                <tbody>
                  <?php
				  $x=1;
                    $sql = "SELECT f.request_id,f.user_id,f.car_id,f.request_date,f.km,f.req_fuel_qty,f.status,f.rec_amount,f.ap_amount,f.comments,f.locations,f.bill,f.approve_reject_level1,f.approve_reject_level2,f.approve_reject_date,f.ap_rej_comments,u.id,u.username,u.phone,u.firstname,u.lastname,u.nid,u.job_title,u.level,u.photo,c.car_id,c.plateno,c.model,c.cardno,c.status as car from fuels_request f LEFT JOIN users u ON f.user_id=u.id LEFT JOIN cars c ON  f.car_id=c.car_id WHERE f.status='approved' AND f.approve_reject_level2<>'' ORDER BY f.request_date DESC";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){?>
					<tr>
					<td><?php echo $x;?></td>
					<td><?php echo $row['request_date'];?></td>
					<td><?php echo $row['firstname']."&nbsp;".$row['lastname'];?></td>
					<td><?php echo $row['km'];?></td>
					
					<td><?php echo $row['plateno'];?></td>
					<td><?php echo $row['cardno'];?></td>
					<td><?php echo $row['model'];?></td>
					<td>Amount Requested:<?php echo number_format($row['rec_amount'],2)."<b>RWF</b>";?><br>
					Approved Amount:<?php echo number_format($row['ap_amount'],2)."<b>RWF</b>";?>
					
					</td>
					<td><?php echo $row['locations'];?></td> 
										 <td>
					 
					 <?php if($row['approve_reject_level1']==''){ 
					 }
					else if($row['approve_reject_level2']=='' && $user['level']=='hr'){
					 echo"<button class='btn btn-success btn-sm approve btn-flat' data-id='".$row['request_id']."'><i class='fa fa-edit'></i>Final Approve</button>
					 <button class='btn btn-danger btn-sm reject btn-flat' data-id='".$row['request_id']."'><i class='fa fa-trash'></i>Reject</button>";
					 }
					 
					 else if($row['approve_reject_level2']!='' && $user['level']=='hr')
					 {
					 echo"requisition approved on".$row['approve_reject_date']."<button class='btn btn-primary btn-sm reject btn-flat' data-id='".$row['request_id']."'><i class='fa fa-eye'></i></button>";
					 }
					 else if($row['approve_reject_level2']!='' && $row['approve_reject_level1']!='' && $user['level']=='hr' || $user['level']=='logistic')
					 {
					 echo "requisition approved on".$row['approve_reject_date']."<button class='btn btn-primary btn-sm reject btn-flat' data-id='".$row['request_id']."'><i class='fa fa-eye'></i></button>";
					 }
					 ?>
                            
                          </td>    
                  </tr>
				  <?php
				  }
				  ?>
                </tbody>
              </table>
		</div>
		</div>
	</div>
</div>

			 
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
   <script src="java_file/jquery-3.2.1.js"></script>
<script src = "java_file/jquery.dataTables.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		$('#table').DataTable();
	});
</script>
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/car_modal.php'; ?>

<?php include 'includes/scripts.php'; ?>
 <script>
	var dtTable;
	$(document).ready(function(){
		$('.table td,.table th').addClass('py-1 px-2 align-middle')
		dtTable = $('.table').dataTable();
		$('#filter-data').submit(function(e){
			e.preventDefault()
			location.href = location.href +"&"+$(this).serialize() 
		})

		$('#print').click(function(){
            start_loader()
			dtTable.fnDestroy();
            var _el = $('<div>')
            var _head = $('head').clone()
                _head.find('title').text("Visitors Logs List - Print View")
            var p = $('#print_out').clone()
            p.find('tr.text-light').removeClass("text-light bg-navy")
            _el.append(_head)
            _el.append('<div class="d-flex justify-content-center">'+
                      '<div class="col-1 text-right">'+
                      '<img src="" width="65px" height="65px" />'+
                      '</div>'+
                      '<div class="col-10">'+
                      '<h4 class="text-center">REPORTS</h4>'+
                      '<h4 class="text-center">Visitors Logs List</h4>'+
                      '</div>'+
                      '<div class="col-1 text-right">'+
                      '</div>'+
                      '</div><hr/>')
            _el.append(p.html())
            var nw = window.open("","","width=1200,height=900,left=250,location=no,titlebar=yes")
                     nw.document.write(_el.html())
                     nw.document.close()
                     setTimeout(() => {
                         nw.print()
                         setTimeout(() => {
                            nw.close()
                            end_loader()
							dtTable = $('.table').dataTable();
                         }, 200);
                     }, 500);
        })
	})
	
</script>
</body>
</html>

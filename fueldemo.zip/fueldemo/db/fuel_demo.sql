-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2023 at 12:21 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fuel_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `bajets`
--

CREATE TABLE `bajets` (
  `bajet_id` int(11) NOT NULL,
  `opening_balance` float NOT NULL,
  `open_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bajets`
--

INSERT INTO `bajets` (`bajet_id`, `opening_balance`, `open_date`) VALUES
(1, 200000, '2022-09-04'),
(2, 200000, '2022-11-17');

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `car_id` int(100) NOT NULL,
  `plateno` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `cardno` varchar(100) NOT NULL,
  `driver_id` int(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`car_id`, `plateno`, `model`, `cardno`, `driver_id`, `status`) VALUES
(1, 'GR796D', 'PICK-UP', '1384004852', 10, 'active'),
(2, 'GR797D', 'PICK-UP', '1384004692', 11, 'active'),
(4, 'GR798D', 'PICK-UP', '1384012320', 12, 'active'),
(5, 'GR799D', 'PICK-UP', '1384004853', 13, 'active'),
(6, 'GR094E', 'PICK-UP', '1384010681', 14, 'active'),
(7, 'GR095E', 'PICK-UP', '1384010692', 15, 'active'),
(8, 'GR096E', 'PICK-UP', '1384010683', 16, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `fuels_request`
--

CREATE TABLE `fuels_request` (
  `request_id` int(100) NOT NULL,
  `user_id` int(100) DEFAULT NULL,
  `car_id` varchar(100) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `req_fuel_qty` float DEFAULT NULL,
  `km` float DEFAULT NULL,
  `unit_price` float DEFAULT NULL,
  `total_price` float DEFAULT NULL,
  `rec_amount` float DEFAULT NULL,
  `ap_amount` float DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `locations` varchar(100) DEFAULT NULL,
  `bill` text DEFAULT NULL,
  `approve_reject_level1` varchar(100) DEFAULT NULL,
  `level1_date` date DEFAULT NULL,
  `approve_reject_level2` varchar(100) DEFAULT NULL,
  `approve_reject_date` date DEFAULT NULL,
  `ap_rej_comments` text DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fuels_request`
--

INSERT INTO `fuels_request` (`request_id`, `user_id`, `car_id`, `request_date`, `req_fuel_qty`, `km`, `unit_price`, `total_price`, `rec_amount`, `ap_amount`, `comments`, `locations`, `bill`, `approve_reject_level1`, `level1_date`, `approve_reject_level2`, `approve_reject_date`, `ap_rej_comments`, `status`) VALUES
(1, 10, '1', '2022-09-05', 6.21504, 50000, 1609, 10000, 60000, 10000, 'kusaba guhabwa essance ', 'Karongi', '', 'logistic approved', '2022-09-05', 'cordinator approved', '2022-09-05', 'final approved', 'approved'),
(2, 11, '2', '2022-09-05', 43.5053, 8000, 1609, 70000, 55000, 50000, 'Gusaba essance', 'Rubavu', '', 'logistic approved', '2022-09-06', 'cordinator approved', '2022-09-06', 'approved', 'approved'),
(3, 12, '4', '2022-09-05', 40.3978, 200000, 1609, 65000, 60000, 0, 'Gusaba essance', 'Rusizi', '', 'logistic approved', '2022-09-06', 'cordinator Rejected', '0000-00-00', 'no no', 'rejected'),
(4, 16, '8', '2022-09-06', 62.1504, 6700, 1609, 100000, 100000, 100000, 'essance irashize', 'NYAMAGABE', NULL, 'logistic approved', '2022-09-08', 'cordinator approved', '2022-09-08', 'cord approve', 'approved'),
(5, 10, '1', '2022-09-08', 37.2902, 46000, 1609, 60000, NULL, NULL, 'oil request', 'Rubavu', NULL, 'logistic Rejected', '2022-09-08', NULL, NULL, 'Nta budget ihari', 'rejected'),
(6, 11, '2', '2022-09-08', 12.4301, 50000, 1609, 20000, 20000, NULL, 'GUSABA ESANSE', '', NULL, 'logistic approved', '2022-09-08', 'cordinator Rejected', NULL, 'rejecting', 'rejected'),
(7, 15, '7', '2022-09-08', 62.1504, 6700, 1609, 100000, 80000, NULL, 'essance', 'NYAMAGABE', NULL, 'logistic approved', '2022-09-08', NULL, NULL, 'approve', 'approved'),
(8, 11, '2', '2022-09-21', 124.301, 124500, 1609, 200000, 100000, 100000, 'Fuel request', 'Karongi', NULL, 'logistic approved', '2022-09-21', 'cordinator approved', '2022-09-21', 'Approved', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `stock_id` int(11) NOT NULL,
  `opening_balance` float NOT NULL,
  `clasing_balance` float NOT NULL,
  `open_date` date NOT NULL,
  `clasing_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`stock_id`, `opening_balance`, `clasing_balance`, `open_date`, `clasing_date`) VALUES
(1, 1639790, 1439790, '2022-11-17', '2022-09-21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(60) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `nid` varchar(100) NOT NULL,
  `job_title` varchar(100) NOT NULL,
  `level` varchar(100) NOT NULL,
  `driving_licence` varchar(100) NOT NULL,
  `exp_date` varchar(100) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `created_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `phone`, `password`, `firstname`, `lastname`, `nid`, `job_title`, `level`, `driving_licence`, `exp_date`, `photo`, `created_on`) VALUES
(1, 'admin@admin.com', '0788888888', '$2y$10$eeug8qJN4l0H4H2TfKPsuuTMiJuctiCUjc17O4bgMElfW9aT32q/.', 'HABUMUGISHA', 'Olivier', '1111111111111111', 'System administrator', 'admin', '', '', 'facebook-profile-image.jpeg', '2018-05-03'),
(10, 'pascal.ndayambaje@rmb.gov.rw', '078835566', '$2y$10$n6BE8GOdWLMscJgv/Zdm1OZuGd5lQUvq2dtT4XQ.vrxBzDTj8R3HO', 'NDAYAMBAJE ', 'Pascal', '', '', 'driver', '', '', '', '2022-09-05'),
(11, 'bernard.nzabonimana@rmb.gov.rw', '0788435556', '$2y$10$Ozm7pT1.itObveAqYW8.yO1tBBhNhEujUWllPcZAvqlIMPPjU3xHe', 'NZABONIMANA ', 'Bernard', '', '', 'driver', '', '', '', '2022-09-05'),
(12, 'arnold.ndererimana@rmb.gov.rw', '078543321', '$2y$10$YfiIIUgFyO..b.aYSef7Ke2ZvzpQWogG.At2sFHfr8HZijOtmLXJ.', 'NDERERIMANA ', 'Arnold ', '', '', 'driver', '', '', '', '2022-09-05'),
(13, 'Dieudone.haragirimana@rmb.gov.', '0786554332', '$2y$10$rHhzSI8iM0uuSpXayiUApOZPbUgcQa1QI.lsJSVuaqqkaIaIEr4aq', 'HARAGIRIMANA ', 'Dieudone', '', '', 'driver', '', '', '', '2022-09-05'),
(14, 'JeandeDieu.harerimana@rmb.gov.', '078654321', '$2y$10$KOYZ0sIzsvCPzfdAI62bdes9FwjphAQ4rQLMvGeTTOAY/.Y0ZoT2m', 'HARERIMANA ', 'Jean de Dieu', '', '', 'driver', '', '', '', '2022-09-05'),
(15, 'aphrodice.nsabimpuwe@rmb.gov.r', '078866547', '$2y$10$jKP6CLAvgCl7FWivSD5If.D628bvmjOGWbetWOH90Hqtk8iETJJXW', 'NSABIMPUWE ', 'Aphrodice', '', '', 'driver', '', '', '', '2022-09-05'),
(16, 'anaclet.vuguziga@rmb.gov.rw', '07865443', '$2y$10$QKLdKAdww1zwGtTKxLhbSe.lz3vlLqlye5Aexm2amwXWRNmRan49C', 'VUGUZIGA ', 'Anaclet', '', '', 'driver', '', '', '', '2022-09-05'),
(21, 'dan.mutabazi@rmb.gov.rw', '0786543322', '$2y$10$35k/SnaEVlJeLIJvQUma4uCKe.wPHwPoU.O1K9C68gXW7hvPRG5aq', 'Dan', 'MUTABAZI', '', '', 'cordinator', '', '', '', '2022-09-05'),
(22, 'evelyne.ingabire@rmb.gov.rw', '0786543245', '$2y$10$i0ViOW4Lx4sdjZIWjlTWcufxQWrf5w8mEkVI0/ryyAzUtgcIJAj/6', 'Evelyne', 'INGABIRE', '', '', 'logistic', '', '', '', '2022-09-05'),
(23, 'kk@gmail.com', '0788843663', '$2y$10$Z9WMSZxCtUX6CfuOlbFAGeXojNyQkJhWgdR5dcHxPMzgWHxu32HeO', 'kabanda', 'john', '', '', 'driver', '', '', '', '2023-03-02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bajets`
--
ALTER TABLE `bajets`
  ADD PRIMARY KEY (`bajet_id`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `fuels_request`
--
ALTER TABLE `fuels_request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bajets`
--
ALTER TABLE `bajets`
  MODIFY `bajet_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `car_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `fuels_request`
--
ALTER TABLE `fuels_request`
  MODIFY `request_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

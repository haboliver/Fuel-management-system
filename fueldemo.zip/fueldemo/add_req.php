<?php
	include 'includes/session.php';

	if(isset($_POST['save'])){
	$user=$_POST['user_id'];
	$car=$_POST['car'];
	$am=$_POST['amount'];
	$qty=$am/1609;
	$location=$_POST['location'];
	$comment=$_POST['comments'];
	$km=$_POST['km'];
	$unit=$_POST['unit'];
	
	if($insert=$conn->query("INSERT INTO `fuels_request`(`user_id`, `car_id`, `request_date`, `req_fuel_qty`, `km`, `unit_price`, `total_price`, `comments`, `locations`, `status`) VALUES ('$user','$car',now(),'$qty','$km','$unit','$am','$comment','$location','pending')"))
	{
	$_SESSION['success']="Requisition Sent Successfully!!";
	}
	else
	{
	$_SESSION['error'] = $conn->error;
	}
	
	header('location:request_fules.php');
	
	}?>
<?php
	include 'includes/session.php';

	if(isset($_POST['save'])){
	$plate=$_POST['plateno'];
	$model=$_POST['model'];
	$driver=$_POST['driver'];
	$card=$_POST['card'];
	$check=$conn->query("SELECT * FROM `cars` WHERE `plateno`='$plate'");
	if($check->num_rows >1)
	{
	$_SESSION['errors']="This car is allready recorded";
	}
	else if($insert=$conn->query("INSERT INTO `cars`(`plateno`, `model`, `cardno`, `driver_id`, `status`) VALUES ('$plate','$model','$card','$driver','active')"))
	{
	$_SESSION['success']="Car Recorded Successfully!!";
	}
	else
	{
	$_SESSION['error'] = $conn->error;
	}
	
	header('location:cars.php');
	
	}?>
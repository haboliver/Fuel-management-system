<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Pending Requisition List
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li>Pending Request fuel</li>
        <li class="active">Request List</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <!--<a href="#addreq" data-toggle="modal" class="btn btn-primary btn-sm btn-flat"><i class="fa fa-plus"></i> New Requisition</a>-->
            </div>
            <div class="box-body">
			<?php
			if($user['level']=='logistic')
			{
			?>
              <table id="example1" class="table table-bordered">
                <thead>
				<th>#</th>
				 <th>Req.Date</th>
                  <th>Full Names</th>
                  <th>KM</th>
                 
				  <th>PlateNo</th>
				  <th>CardNo</th>
				  <th>Model</th>
                  <th>Amount</th>
                  <th>Location</th>
				  <th>Comments</th>
                  <th>Tools</th>
                </thead>
                <tbody>
                  <?php
				  $x=1;
                    $sql = "SELECT f.request_id,f.user_id,f.car_id,f.request_date,f.km,f.req_fuel_qty,f.total_price,f.status,f.comments,f.locations,f.bill,f.approve_reject_level1,f.approve_reject_level2,f.approve_reject_date,f.ap_rej_comments,u.id,u.username,u.phone,u.firstname,u.lastname,u.nid,u.job_title,u.level,u.photo,c.car_id,c.plateno,c.model,c.cardno,c.status as car from fuels_request f LEFT JOIN users u ON f.user_id=u.id LEFT JOIN cars c ON  f.car_id=c.car_id WHERE f.status='pending' OR f.approve_reject_level2='' ORDER BY f.request_date DESC";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){?>
					<tr>
					<td><?php echo $x;?></td>
					<td><?php echo $row['request_date'];?></td>
					<td><?php echo $row['firstname']."&nbsp;".$row['lastname'];?></td>
					<td><?php echo $row['km'];?></td>
					
					<td><?php echo $row['plateno'];?></td>
					<td><?php echo $row['cardno'];?></td>
					<td><?php echo $row['model'];?></td>
					<td><?php echo number_format($row['total_price'],2)."<b>RWF</b>";?></td>
					<td><?php echo $row['locations'];?></td> 
					<td><?php echo $row['comments'];?></td>
					 <td>
					 
					 <?php if($row['approve_reject_level1']=='' && $user['level']=='logistic'){ echo"<button class='btn btn-success btn-sm approve btn-flat' data-id='".$row['request_id']."'><i class='fa fa-edit'></i>Approve</button>
					 <button class='btn btn-danger btn-sm reject btn-flat' data-id='".$row['request_id']."'><i class='fa fa-trash'></i>Reject</button>";
					 }
					if($row['approve_reject_level1']!='' && $user['level']=='hr'){
					 echo"<button class='btn btn-success btn-sm approve btn-flat' data-id='".$row['request_id']."'><i class='fa fa-edit'></i>Final Approve</button>
					 <button class='btn btn-danger btn-sm reject btn-flat' data-id='".$row['request_id']."'><i class='fa fa-trash'></i>Reject</button>";
					 }
					 else
					 {
					 echo "Pending";
					 }
					 ?>
                            
                          </td>    
                  </tr>
				  <?php
				  }
				  ?>
                </tbody>
              </table>
			  
			  <?php
			  }
			  else if($user['level']=='cordinator')
			  {
			  ?>
			  <table id="example1" class="table table-bordered">
                <thead>
				<th>#</th>
				 <th>Req.Date</th>
                  <th>FullNames</th>
                  <th>KM</th>
                 
				  <th>PlateNo</th>
				  <th>CardNo</th>
				  <th>Model</th>
                  <th>Amount</th>
                  <th>Location</th>
				  <th>Comments</th>
                  <th>Tools</th>
                </thead>
                <tbody>
                  <?php
				  $x=1;
                    $sql = "SELECT f.request_id,f.user_id,f.car_id,f.request_date,f.km,f.req_fuel_qty,f.total_price,f.status,f.comments,f.locations,f.bill,f.approve_reject_level1,f.approve_reject_level2,f.approve_reject_date,f.ap_rej_comments,u.id,u.username,u.phone,u.firstname,u.lastname,u.nid,u.job_title,u.level,u.photo,c.car_id,c.plateno,c.model,c.cardno,c.status as car from fuels_request f LEFT JOIN users u ON f.user_id=u.id LEFT JOIN cars c ON  f.car_id=c.car_id WHERE f.status='approved' AND f.approve_reject_level2 IS NULL ORDER BY f.request_date DESC";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){?>
					<tr>
					<td><?php echo $x;?></td>
					<td><?php echo $row['request_date'];?></td>
					<td><?php echo $row['firstname']."&nbsp;".$row['lastname'];?></td>
					<td><?php echo $row['km'];?></td>
					
					<td><?php echo $row['plateno'];?></td>
					<td><?php echo $row['cardno'];?></td>
					<td><?php echo $row['model'];?></td>
					<td><?php echo number_format($row['total_price'],2)."<b>RWF</b>";?></td>
					<td><?php echo $row['locations'];?></td> 
					<td><?php echo $row['comments'];?></td>
					 <td>
					 
					 <?php if($row['approve_reject_level1']=='' && $user['level']=='logistic'){ echo"<button class='btn btn-success btn-sm approve btn-flat' data-id='".$row['request_id']."'><i class='fa fa-edit'></i>Approve</button>
					 <button class='btn btn-danger btn-sm reject btn-flat' data-id='".$row['request_id']."'><i class='fa fa-trash'></i>Reject</button>";
					 }
					if($row['approve_reject_level1']!='' && $user['level']=='hr'|| $user['level']=='cordinator'){
					 echo"<button class='btn btn-success btn-sm fapprove btn-flat' data-id='".$row['request_id']."'><i class='fa fa-edit'></i>Final Approve</button>
					 <button class='btn btn-danger btn-sm reject btn-flat' data-id='".$row['request_id']."'><i class='fa fa-trash'></i>Reject</button>";
					 }
					 else
					 {
					 echo "";
					 }
					 ?>
                            
                          </td>    
                  </tr>
				  <?php
				  }
				  ?>
                </tbody>
              </table>
			  <?php
			  }
			  else
			  {
			  echo "";
			  }
			  ?>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
   
  <?php include 'includes/footer.php'; ?>
</div>

<?php include 'includes/scripts.php'; ?>

<script>
$(function(){
  $(document).on('click', '.approve', function(e){
    e.preventDefault();
    $('#approve').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.reject', function(e){
    e.preventDefault();
    $('#reject').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.photo', function(e){
    e.preventDefault();
    var id = $(this).data('id');
    getRow(id);
  });

});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'approve_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('#id').val(response.request_id);
      $('#edit_firstname').val(response.firstname);
      $('#edit_lastname').val(response.lastname);
   
      $('.driver').html(response.firstname+'&nbsp;'+response.lastname);
	  $('.plate').html(response.plateno);
	  $('.liters').html(response.req_fuel_qty);
	  $('#card').html(response.cardno);
	   $('#amount').val(response.total_price);
	    $('.request').val(response.request_id);
	   $('.model').html(response.model);
    }
  });
}
</script>


<?php include 'includes/reject_modal.php'; ?>



<script>
$(function(){
  $(document).on('click', '.fapprove', function(e){
    e.preventDefault();
    $('#fapprove').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.delete', function(e){
    e.preventDefault();
    $('#reject').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

  $(document).on('click', '.photo', function(e){
    e.preventDefault();
    var id = $(this).data('id');
    getRow(id);
  });

});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'approve_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('#id').val(response.request_id);
      $('#edit_firstname').val(response.firstname);
      $('#edit_lastname').val(response.lastname);
   
      $('.driver').html(response.firstname+'&nbsp;'+response.lastname);
	  $('.plate').html(response.plateno);
	  $('.liters').html(response.req_fuel_qty);
	  $('.card').html(response.cardno);
	   $('.amount').val(response.total_price);
	   $('.am').val(response.rec_amount);
	      $('.re').val(response.request_id);
	   $('.model').html(response.model);
    }
  });
}
</script>
<!-- Add -->
<div class="modal fade" id="approve">
    <div class="modal-dialog">
        <div class="modal-content">
          	<div class="modal-header">
            	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
              		<span aria-hidden="true">&times;</span></button>
            	<h4 class="modal-title"><b>Approve  Requisition........</b></h4>
          	</div>
          	<div class="modal-body">
            	<form class="form-horizontal" method="POST" action="approve_req_level1.php">
				
          		  <div class="form-group">
                  <div class="text-center">
				  
				  <input type="hidden" name="user" value="<?php echo $user['level'];?>" />
	                	<h2>Are you sure you want to approve this Requisition?</h2>
	                	<input type="hidden" name="id" class="re" />
	               
					<p>CardNo:<i class="card"></i></p>
					<p>Driver Name:<i class="driver"></i></p>
				
					<p>Amount Requested:<input type="text" name="amount" class="amount"></i>RWF</p>
					
					<textarea rows="4" cols="20" name="comment"  class="form-control" placeholder="type comment..." required></textarea>
	            	</div>
                </div>
               
                         	<div class="modal-footer">
            	<button type="button" class="btn btn-danger btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i>No</button>
            	<button type="submit" class="btn btn-primary btn-flat" name="update"><i class="fa fa-check"></i>Yes</button>
            	</form>
          	</div>
        </div>
    </div>
</div>
</div>
<?php include 'includes/approve_modal.php'; ?>

</body>
</html>
